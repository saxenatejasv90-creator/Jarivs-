# FRIDAY — Local Kokoro Android integration plan

## Decision

Target: **same Android phone, local speech synthesis**.

AI brain: Grok API (online).
Speech generation: Kokoro model running locally on Android (offline after model assets are installed).
Playback: Android audio output.

## Important compatibility finding

The supplied repository, https://github.com/PierrunoYT/Kokoro-TTS-Local, is a Python desktop application. Its documented stack includes Python 3.10–3.12, PyTorch, Kokoro/Misaki, and supporting Python packages. It documents Windows, Linux, and macOS support; it does not document an Android APK runtime or Android-native inference library.

Therefore, simply copying that repository into this Android project would not create a working on-device Kokoro engine. Packaging its full Python/PyTorch stack into a normal APK is not the recommended mobile approach.

## Android implementation path

1. Keep the app-facing `SpeechEngine` contract in `app/src/main/java/com/friday/assistant/tts/SpeechEngine.kt`.
2. Select or build an Android-native Kokoro runtime (for example, a compatible ONNX Runtime Android implementation, with Kokoro model conversion, phonemizer/G2P, voice embeddings, and audio decoding handled correctly).
3. Verify that the chosen runtime supports the target phone's CPU/ABI, Android version, RAM, and required language/voice. Do not assume that a desktop `.pth` checkpoint can be loaded directly by Android.
4. Download model, config, phonemizer assets, and selected voice files on first setup. Store them in app-private storage; do not bundle large weights inside the APK.
5. Add a model manager with download progress, free-space checks, checksum validation, cancellation, and a clear offline-ready state.
6. Implement `KokoroLocalSpeechEngine : SpeechEngine` using the selected native runtime. Run inference off the UI thread and stream or buffer PCM safely into Android audio playback.
7. Add voice and speed settings. Start with one supported voice and add more only after language and pronunciation tests pass.
8. Test cold start, repeated utterances, interruptions, low-memory behavior, airplane mode, and app lifecycle cleanup on the actual phone.

## Current project status

- Added a stable `SpeechEngine` interface so the UI can be connected to a real engine without being rewritten.
- No Kokoro model or native inference runtime is bundled yet.
- Kokoro is **not yet generating speech inside this APK**. This is intentional; claiming otherwise would be misleading.
- The current repository's Python implementation remains a reference for model behavior, voices, and offline asset requirements, not an Android runtime dependency.

## Hardware note

A separate community Android Kokoro implementation exists, but its published hardware qualification is specifically for a Snapdragon 8 Gen 3 Galaxy S24 Ultra, with a specialized Qualcomm HTP path. That is not evidence it will run well on other phones. Device-specific compatibility must be checked before adopting it.

## Grok and key safety

The Grok API key must not be hard-coded in Kotlin, resources, or the APK. Use a small authenticated backend to hold the key, or another secure secret-management design. Kokoro speech generation itself should not require sending response text to a third-party TTS service.

## Acceptance criteria

- FRIDAY can speak a generated response with network disabled after model setup.
- Model assets remain in app-private storage and survive app restarts.
- UI remains responsive during inference.
- Stop/cancel interrupts speech cleanly.
- Low-memory devices fail gracefully and explain when the selected model is unsupported.
