package com.friday.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF070D18)
private val Panel = Color(0xFF101B2B)
private val Panel2 = Color(0xFF14243A)
private val Cyan = Color(0xFF66D9FF)
private val Blue = Color(0xFF4A8DFF)
private val Muted = Color(0xFF8294AA)
private val White = Color(0xFFEAF5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FridayApp() }
    }
}

@Composable
fun FridayApp() {
    var activeTab by remember { mutableStateOf("Home") }
    var command by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("All systems are online. How can I help you?") }
    var listening by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf("Good afternoon. I'm FRIDAY, your personal assistant.")) }
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to FRIDAY")
                }
                try {
                    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
                    recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) { listening = true }
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() { listening = false }
                        override fun onError(error: Int) { listening = false; recognizer.destroy() }
                        override fun onResults(results: Bundle?) {
                            listening = false
                            val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                            if (!spoken.isNullOrBlank()) command = spoken
                            recognizer.destroy()
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                    recognizer.startListening(intent)
                } catch (_: Exception) { listening = false }
            } else {
                response = "Speech recognition is not available on this device."
            }
        } else response = "Microphone permission is needed for voice input."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan, onBackground = White,
        onSurface = White, secondary = Blue
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0B1728), Bg, Color(0xFF050A12)))
        )) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                TopBar()
                when (activeTab) {
                    "Home" -> HomeScreen(
                        listening = listening,
                        response = response,
                        command = command,
                        onCommandChange = { command = it },
                        onSend = {
                            if (command.isNotBlank()) {
                                val q = command.trim()
                                history = history + "You: $q"
                                response = localReply(q)
                                history = history + "FRIDAY: $response"
                                command = ""
                            }
                        },
                        onMic = {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (granted) speechLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            else speechLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onQuickAction = { action ->
                            command = action
                            response = "Ready to help with: $action"
                        }
                    )
                    "Activity" -> ActivityScreen(history)
                    else -> SettingsScreen()
                }
                Spacer(Modifier.weight(1f))
                BottomNav(activeTab) { activeTab = it }
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("F R I D A Y", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(7.dp).background(Color(0xFF55E6B0), CircleShape))
            Text("ONLINE", color = Color(0xFF77E8B9), fontSize = 10.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Default.Settings, null, tint = Muted, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun ColumnScope.HomeScreen(
    listening: Boolean,
    response: String,
    command: String,
    onCommandChange: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onQuickAction: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column {
                Text("Good afternoon.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Light)
                Text("What would you like me to do?", color = Muted, fontSize = 14.sp)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().height(245.dp), contentAlignment = Alignment.Center) {
                val infinite = rememberInfiniteTransition(label = "orb")
                val pulse by infinite.animateFloat(
                    initialValue = 0.92f, targetValue = 1.08f,
                    animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                    label = "pulse"
                )
                Box(Modifier.size(205.dp).scale(pulse).border(1.dp, Cyan.copy(alpha = .16f), CircleShape).background(
                    Brush.radialGradient(listOf(Blue.copy(alpha = .18f), Cyan.copy(alpha = .035f), Color.Transparent)), CircleShape
                ))
                Box(Modifier.size(154.dp).border(1.dp, Cyan.copy(alpha = .35f), CircleShape).background(
                    Brush.radialGradient(listOf(Color(0xFF1C5D8C), Color(0xFF102B4B), Color(0xFF091629))), CircleShape
                ), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(95.dp).border(1.dp, Cyan.copy(alpha = .65f), CircleShape).background(
                        Brush.radialGradient(listOf(Cyan.copy(alpha = .28f), Blue.copy(alpha = .12f), Color.Transparent)), CircleShape
                    ), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(43.dp))
                    }
                }
                Column(Modifier.align(Alignment.BottomCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (listening) "LISTENING" else "READY WHEN YOU ARE", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text("FRIDAY CORE  •  v1.0", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            }
        }
        item {
            Surface(color = Panel.copy(alpha = .92f), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF203650))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("FRIDAY", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(response, color = White, fontSize = 14.sp, lineHeight = 21.sp)
                }
            }
        }
        item {
            Text("QUICK ACCESS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard("Research", Icons.Default.Search, Modifier.weight(1f)) { onQuickAction("Help me research a topic") }
                QuickCard("Write code", Icons.Default.Code, Modifier.weight(1f)) { onQuickAction("Help me write code") }
                QuickCard("Explore", Icons.Default.Language, Modifier.weight(1f)) { onQuickAction("Help me explore the web") }
            }
        }
        item {
            Surface(color = Panel2.copy(alpha = .72f), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF27415F))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, null, tint = Muted)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (command.isEmpty()) Text("Ask FRIDAY anything...", color = Muted, fontSize = 13.sp)
                        BasicTextField(
                            value = command, onValueChange = onCommandChange,
                            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp),
                            cursorBrush = SolidColor(Cyan),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { onSend() }),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    IconButton(onClick = onMic) {
                        Icon(Icons.Default.Mic, null, tint = Cyan)
                    }
                    IconButton(onClick = onSend) {
                        Icon(Icons.Default.Send, null, tint = Cyan)
                    }
                }
            }
        }
        item {
            Text("SYSTEM SNAPSHOT", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoTile("CORE", "Standby", Icons.Default.Memory, Modifier.weight(1f))
                InfoTile("VOICE", "Available", Icons.Default.MicNone, Modifier.weight(1f))
                InfoTile("NETWORK", "Connected", Icons.Default.Wifi, Modifier.weight(1f))
            }
        }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun QuickCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF203650))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp))
            Text(title, color = White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun InfoTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Surface(modifier, color = Panel.copy(alpha = .8f), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(16.dp))
            Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
            Text(value, color = White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ColumnScope.ActivityScreen(history: List<String>) {
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("Activity", color = White, fontSize = 27.sp, fontWeight = FontWeight.Light)
        Text("Your recent conversations", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        history.asReversed().forEach { line ->
            Surface(Modifier.fillMaxWidth().padding(bottom = 9.dp), color = Panel, shape = RoundedCornerShape(14.dp)) {
                Text(line, Modifier.padding(14.dp), color = White, fontSize = 13.sp)
            }
        }
        if (history.isEmpty()) Text("Your activity will appear here.", color = Muted)
    }
}

@Composable
private fun ColumnScope.SettingsScreen() {
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Settings", color = White, fontSize = 27.sp, fontWeight = FontWeight.Light)
        Text("Personalise your assistant", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        listOf("Assistant identity" to "FRIDAY", "Interface theme" to "Midnight blue", "AI brain" to "Grok API (planned)", "Voice input" to "Android speech recognition", "Speech output" to "Kokoro local (adapter planned)", "Offline voice" to "Not installed yet", "Version" to "1.0").forEach { (a, b) ->
            Surface(Modifier.fillMaxWidth().padding(bottom = 10.dp), color = Panel, shape = RoundedCornerShape(15.dp)) {
                Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(a, color = White, fontSize = 13.sp)
                    Text(b, color = Cyan, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Kokoro local speech is planned but not active yet. The supplied Kokoro-TTS-Local project is Python desktop software; FRIDAY needs a compatible Android-native inference runtime before it can speak offline. See KOKORO_ANDROID_INTEGRATION.md in the project.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun BottomNav(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF091321)).padding(horizontal = 24.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceAround) {
        listOf("Home" to Icons.Default.Home, "Activity" to Icons.Default.Forum, "Settings" to Icons.Default.Settings).forEach { (name, icon) ->
            Column(Modifier.clickable { onSelect(name) }.padding(horizontal = 14.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = if (selected == name) Cyan else Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.height(4.dp))
                Text(name, color = if (selected == name) Cyan else Muted, fontSize = 9.sp)
            }
        }
    }
}

private fun localReply(input: String): String {
    val q = input.lowercase(Locale.getDefault())
    return when {
        "hello" in q || "hi" in q -> "Hello. FRIDAY systems are ready. What can I assist you with?"
        "time" in q -> "I can add a live clock integration in the next development step."
        "research" in q -> "Research mode selected. Connect an AI provider to enable live research and sourced answers."
        "code" in q -> "Development mode selected. Tell me what you want to build, and connect an AI provider for generated code."
        "web" in q || "browser" in q -> "Web exploration selected. Browser integration is not connected in this starter build."
        else -> "I received your request: \"$input\". This starter interface is working locally; connect an AI backend to generate intelligent responses."
    }
}
