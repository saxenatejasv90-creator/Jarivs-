package com.friday.assistant.tts

/**
 * FRIDAY speech output contract.
 *
 * The Android UI talks to this interface instead of depending on a specific
 * TTS implementation. A native Kokoro Android runtime can be plugged in here
 * once its Android model/runtime format and supported devices are selected.
 */
interface SpeechEngine {
    val engineName: String
    val isReady: Boolean

    suspend fun initialize(): SpeechEngineResult
    suspend fun speak(text: String, voiceId: String, speed: Float = 1.0f): SpeechEngineResult
    fun stop()
    fun release()
}

data class SpeechEngineResult(
    val success: Boolean,
    val message: String,
    val audioDurationMs: Long? = null
)

enum class SpeechEngineState {
    NOT_INSTALLED,
    DOWNLOADING_MODEL,
    INITIALIZING,
    READY,
    ERROR
}
