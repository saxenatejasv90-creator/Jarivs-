# FRIDAY — Android starter project

A native Android app starter built with Kotlin + Jetpack Compose.

## Included
- FRIDAY-inspired midnight-blue mobile dashboard
- Animated central assistant core
- Chat composer and local demo responses
- Android speech-to-text permission flow
- Quick access cards for research, coding, and web exploration
- Activity and Settings tabs
- Speech-engine interface for a future native Kokoro runtime
- Kokoro Android integration plan (`KOKORO_ANDROID_INTEGRATION.md`)

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`FridayJarvisAndroid`) in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location.

## AI and voice status
- Chat currently uses local demo replies; Grok is not connected yet.
- Microphone input uses Android speech recognition.
- Kokoro has an app-facing `SpeechEngine` interface, but no Android-native Kokoro model runtime is included yet.
- The supplied `PierrunoYT/Kokoro-TTS-Local` repository is a Python desktop application, not a drop-in Android library. See `KOKORO_ANDROID_INTEGRATION.md` before choosing the native runtime.
- Keep the Grok API key out of the APK. Use a secure backend for API requests.

## Requirements
- Android Studio with JDK 17
- Android SDK 35
- Minimum Android 8.0 (API 26)

## Build the APK with GitHub (no Android Studio needed)
1. Push this folder to a GitHub repository (the project files must be at the repo root).
2. Open the **Actions** tab, then **Build APK**, then **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download **FRIDAY-debug-apk** under Artifacts.
4. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").
